# CSMusicMixer
A recreation and modernisation of the MyCoke Music Mixer licensed under The MIT License.

You can view it on GitHub pages here: https://markehme.github.io/CSMusicMixer/index.html

**please note** this will be riddled with bugs, feel free to report them.

# Supported Browers
* Google Chrome v39+ - developed on Google Chrome v39+ and is deemed to work
* FireFox 35.0.1+  - tested on FireFox for Mac, it works

# Unsupported Browsers
* Mobile Browsers: Although it may play, the sizing is not optimised for it
* Safari: Safari has issues with audio elements. It attempts to download the first few bytes before playing them, or something like that.. causing timing issues. Read here: http://stackoverflow.com/questions/1995589/html5-audio-safari-live-broadcast-vs-not
